EK SODOS ATTENDANCE SYSTEM — VERSION 3

RUN
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, Firefox or another modern browser.

DEMO ADMIN LOGIN
Username: admin
Password: Admin@12345

DEMO EMPLOYEE LOGINS
EKS001 | Ifedamola Joseph Fayomi | username: ifedamola | password: Welcome123
EKS002 | Employee Two            | username: employee2 | password: Welcome123
EKS003 | Employee Three          | username: employee3 | password: Welcome123

FEATURES IN THIS VERSION
- Separate employee and administrator login tabs.
- Employee sessions open only the employee attendance screen.
- Admin can create employee accounts with employee ID, username and password.
- Admin can deactivate/reactivate accounts.
- Employees cannot open the admin dashboard through the normal employee session.
- Weekly attendance filtering: choose any date; the system shows Monday to Sunday for that week.
- Export the selected week to CSV (the name search filter is also applied).
- Attendance is keyed to the local calendar date. A new attendance record becomes available automatically at 12:00 midnight local time each new day.
- Duplicate sign-in on the same calendar day is prevented; sign-out completes that day's record.
- Arrival status is automatic: before 8:00 AM = EARLY; exactly 8:00 AM = ON TIME; after 8:00 AM = LATE. The status appears in employee history, the admin attendance table and CSV exports.

IMPORTANT SECURITY / DEPLOYMENT LIMITATION
This is still a browser-only demonstration. The records, account list and password comparisons are stored in localStorage in the browser. This is NOT secure authentication, and data is not shared between devices or users. Anyone with access to the browser's developer tools could inspect or alter the stored data. The demo credentials are public in this README.

Before company deployment, use a backend such as Firebase or Supabase:
- Store passwords as secure salted hashes using a trusted authentication provider (never store plain-text passwords).
- Enforce employee/admin roles on the server, not only in JavaScript.
- Store attendance centrally in a database.
- Generate timestamps server-side and validate all sign-in/sign-out operations.
- Add secure admin password reset, employee onboarding and audit logs.
- Deploy over HTTPS.

The office resumption time is set to 8:00 AM. Employees signing in before 8:00 AM are marked EARLY; employees signing in after 8:00 AM are marked LATE; exactly 8:00 AM is marked ON TIME.

Branding update: The interface now uses the Eksodos red, deep blue and white brand palette and displays the supplied company logo. Keep eksodos-logo.jpg in the same folder as index.html.
