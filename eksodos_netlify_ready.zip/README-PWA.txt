EK SODOS ATTENDANCE — ANDROID + IPHONE INSTALLABLE WEB APP (PWA)

WHAT THIS IS
This package adds Progressive Web App (PWA) support to the Eksodos attendance website. The same hosted app can be installed on compatible Android phones and iPhones. It uses the supplied Eksodos logo and red, deep-blue and white branding.

IMPORTANT: IT MUST BE HOSTED OVER HTTPS
PWA installation and service workers do not work by simply opening index.html from a ZIP or file:// location. Upload the contents of this folder to an HTTPS web host (for example, your organisation's HTTPS website or a suitable static hosting service). Keep all files in the same folder. Do not rename the manifest, service worker, icons, CSS or JS files.

ANDROID INSTALLATION
1. Open the HTTPS website in Chrome.
2. Tap the browser menu (three dots), then choose Install app or Add to Home screen.
3. Confirm. The Eksodos Attendance icon will appear on the phone.

IPHONE INSTALLATION
1. Open the HTTPS website in Safari (not an in-app browser).
2. Tap the Share button.
3. Choose Add to Home Screen.
4. Confirm the name and tap Add. The Eksodos Attendance icon will appear on the Home Screen.

ABOUT APP STORES
This PWA is installable directly from the website; it is not yet an App Store or Google Play Store listing. Publishing native store apps requires additional packaging, developer accounts, store review and compliance work.

IMPORTANT COMPANY-USE LIMITATION
The underlying attendance system is still the browser-only prototype. Employee accounts and attendance records are stored in local browser storage, not in a shared secure company database. Different employees' phones will NOT automatically share records with the administrator. Do not use it as the organisation's official attendance system until a secure backend is added (for example Firebase or Supabase), with server-side role permissions, secure authentication, central attendance storage and server-validated timestamps. The offline cache only caches the app shell; it does not provide safe multi-device/offline attendance synchronisation.

FILES
index.html, styles.css, app.js, eksodos-logo.jpg, manifest.webmanifest, service-worker.js, icon-192.png, icon-512.png
